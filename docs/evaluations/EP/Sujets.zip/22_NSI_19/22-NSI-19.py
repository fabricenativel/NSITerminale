def chercher(T,n,i,j):
    if i < 0 or ??? :
        print("Erreur")
        return None    
    if i > j :
        return None
    m = (i+j) // ???
    if T[m] < ??? :
        return chercher(T, n, ??? , ???)
    elif ??? :
        return chercher(T, n, ??? , ??? )
    else :
        return ??? 
